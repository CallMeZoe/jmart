package com.ahmadZufarJsmartMH;

@FunctionalInterface
public interface Predicate<T> {
     boolean predicate (T arg);
}
