package com.ahmadZufarJsmartMH;


/**
 * Enumeration class ProductCategory - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum ProductCategory
{
    BOOK, KITCHEN, ELECTRONIC, FASHION, GAMING, GADGET, MOTHERCARE, COSMETICS, HEALTHCARE,
    FURNITURE, JEWELRY, TOYS, FNB, STATIONERY, SPORTS, AUTOMOTIVE, PETCARE, ART_CRAFT,CARPENTRY, 
    MISCELLANEOUS, PROPERTY, TRAVEL, WEDDING
}
