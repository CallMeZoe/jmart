package com.ahmadZufarJsmartMH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AhmadZufarJsmartMhApplication {

	public static void main(String[] args) {
		SpringApplication.run(AhmadZufarJsmartMhApplication.class, args);
	}

}
